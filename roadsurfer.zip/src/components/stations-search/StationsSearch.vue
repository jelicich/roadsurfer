<template>
  <div class="StationsSearch">
    <AutocompleteField
      label="Station"
      placeholder="Start typing..."
      :debounce-time="debounceTime"
      :autocomplete-service="service"
      @change="onStationSelected"
    />
  </div>
</template>

<script lang="ts">
import Vue from "vue";
import { mapState, mapGetters, mapActions } from "vuex";
import AutocompleteField from "@/components/autocomplete-field/AutocompleteField.vue";
import StationsService from "@/services/StationsService";
import { Station } from "@/models";

// Define interface for stations module state
interface StationsState {
  selectedStation: Station | null;
}

export default Vue.extend({
  name: "StationsSearch",

  components: {
    AutocompleteField,
  },

  data() {
    return {
      service: new StationsService(), // Keep existing service for compatibility
      debounceTime: 300,
    };
  },

  computed: {
    ...mapState("stations", {
      selectedStation: (state: StationsState) => state.selectedStation,
    }),
    ...mapGetters("stations", ["isLoading", "hasError", "errorMessage"]),
  },

  methods: {
    ...mapActions("stations", ["selectStation"]),

    onStationSelected(selectedStation: Station | null) {
      this.selectStation(selectedStation);
    },
  },
});
</script>
