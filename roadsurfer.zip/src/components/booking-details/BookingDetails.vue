<template>
  <ModalWindow :show="isModalOpen" title="Booking Details" @close="closeModal">
    <div class="BookingDetails">
      <div v-if="loading" class="BookingDetails-statusMessage is-loading">
        Loading booking details...
      </div>
      <div v-else-if="error" class="BookingDetails-statusMessage is-error">
        {{ error }}
      </div>
      <div v-else-if="booking" class="BookingDetails-content">
        <div class="BookingDetails-field">
          <strong>Booking ID:</strong> {{ booking.id }}
        </div>
        <div class="BookingDetails-field">
          <strong>Customer:</strong> {{ booking.customerName }}
        </div>
        <div class="BookingDetails-field">
          <strong>Station ID:</strong> {{ booking.pickupReturnStationId }}
        </div>
        <div class="BookingDetails-field">
          <strong>Station name:</strong> {{ booking.pickupReturnStationName }}
        </div>
        <div class="BookingDetails-field">
          <strong>Start Date:</strong> {{ formatDate(booking.startDate) }}
        </div>
        <div class="BookingDetails-field">
          <strong>End Date:</strong> {{ formatDate(booking.endDate) }}
        </div>
      </div>
      <div v-else class="BookingDetails-statusMessage is-empty">
        No booking information available.
      </div>
    </div>
  </ModalWindow>
</template>

<script lang="ts">
import Vue from "vue";
import ModalWindow from "@/components/modal-window/ModalWindow.vue";
import { format } from "date-fns";
import { mapState, mapActions } from "vuex";
import { Station } from "@/models";

// Define interfaces for store state
interface StationsState {
  selectedStation: Station | null;
}

interface BookingsState {
  selectedBooking: {
    id: string;
    customerName: string;
    pickupReturnStationId: string;
    pickupReturnStationName: string;
    startDate: string;
    endDate: string;
  } | null;
  loading: boolean;
  error: string | null;
}

export default Vue.extend({
  name: "BookingDetails",
  components: {
    ModalWindow,
  },
  data() {
    return {
      isModalOpen: false,
    };
  },
  computed: {
    ...mapState("stations", {
      selectedStation: (state: StationsState) => state.selectedStation,
    }),
    ...mapState("bookings", {
      booking: (state: BookingsState) => state.selectedBooking,
      loading: (state: BookingsState) => state.loading,
      error: (state: BookingsState) => state.error,
    }),
    stationId(): string {
      return this.$route.params.stationId || "";
    },
    bookingId(): string {
      return this.$route.params.bookingId || "";
    },
  },
  mounted() {
    this.isModalOpen = true;
    this.fetchBookingDetails();
  },

  methods: {
    ...mapActions("bookings", [
      "fetchBookingByStation",
      "clearSelectedBooking",
    ]),

    fetchBookingDetails() {
      if (!this.bookingId || !this.stationId) {
        return;
      }

      this.fetchBookingByStation({
        stationId: this.stationId,
        bookingId: this.bookingId,
      });
    },
    formatDate(dateString: string): string {
      try {
        return format(new Date(dateString), "PPP");
      } catch (e) {
        return dateString;
      }
    },
    closeModal() {
      this.clearSelectedBooking();
      this.$router.push({ path: "/" });
    },
  },
});
</script>
