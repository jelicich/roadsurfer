import { shallowMount, mount, createLocalVue, Wrapper } from "@vue/test-utils";
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import Vue from "vue";
import BookingCalendar from "./BookingCalendar.vue";
import { BookingCalendarModule } from "./BookingCalendarModule";
import Vuex, { Store } from "vuex";
import type { Station, TypedBooking } from "@/models";
import { format } from "date-fns";

// Interfaces for component instance and related types
interface BookingCalendarVue extends Vue {
  bookingCalendarModule: {
    getCurrentWeek: () => Date[];
    goToNextWeek: () => Date[];
    goToPreviousWeek: () => Date[];
    formatDate: (date: Date) => string;
    getBookingsForDay: (day: Date, station: Station) => TypedBooking[];
    goToLatestBooking: (station: Station) => Date[];
  };
  weekDays: Date[];
  getBookingsForDay: (day: Date) => TypedBooking[];
  openBookingDetails: (bookingId: string) => void;
}

// Define state structure for type safety
interface StationsState {
  selectedStation: Station | null;
}

interface Router {
  push: (route: {
    name: string;
    params: { bookingId: string; stationId: string };
  }) => void;
}

// Mock the BookingCalendarModule
vi.mock("./BookingCalendarModule", () => {
  const mockWeekDays = [
    new Date("2025-07-07T00:00:00Z"), // Monday
    new Date("2025-07-08T00:00:00Z"), // Tuesday
    new Date("2025-07-09T00:00:00Z"), // Wednesday
    new Date("2025-07-10T00:00:00Z"), // Thursday
    new Date("2025-07-11T00:00:00Z"), // Friday
    new Date("2025-07-12T00:00:00Z"), // Saturday
    new Date("2025-07-13T00:00:00Z"), // Sunday
  ];

  return {
    BookingCalendarModule: vi.fn().mockImplementation(() => ({
      getCurrentWeek: vi.fn().mockReturnValue(mockWeekDays),
      goToNextWeek: vi
        .fn()
        .mockReturnValue(
          mockWeekDays.map(
            (d) => new Date(d.getTime() + 7 * 24 * 60 * 60 * 1000)
          )
        ),
      goToPreviousWeek: vi
        .fn()
        .mockReturnValue(
          mockWeekDays.map(
            (d) => new Date(d.getTime() - 7 * 24 * 60 * 60 * 1000)
          )
        ),
      formatDate: vi
        .fn()
        .mockImplementation((date: Date) => format(date, "EEE dd MMM yyyy")),
      getBookingsForDay: vi.fn().mockReturnValue([]),
      goToLatestBooking: vi.fn().mockReturnValue(mockWeekDays),
    })),
  };
});

// Mock the date-fns isToday function
vi.mock("date-fns", async () => {
  const actual = await vi.importActual("date-fns");
  return {
    ...(actual as Record<string, unknown>),
    isToday: vi.fn().mockImplementation((date: Date) => {
      // Mock to make 2025-07-10 (Thursday) as "today"
      const today = new Date("2025-07-10T00:00:00Z");
      return (
        date.getFullYear() === today.getFullYear() &&
        date.getMonth() === today.getMonth() &&
        date.getDate() === today.getDate()
      );
    }),
  };
});

describe("BookingCalendar", () => {
  // Mock data
  const mockBookings: TypedBooking[] = [
    {
      id: "booking1",
      pickupReturnStationId: "station1",
      customerName: "John Doe",
      startDate: "2025-07-08T10:00:00Z",
      endDate: "2025-07-12T14:00:00Z",
      type: "pickup",
    },
    {
      id: "booking2",
      pickupReturnStationId: "station1",
      customerName: "Jane Smith",
      startDate: "2025-07-10T09:00:00Z",
      endDate: "2025-07-14T16:00:00Z",
      type: "pickup",
    },
  ];

  const mockStation: Station = {
    id: "station1",
    name: "Test Station",
    bookings: mockBookings,
  };

  let localVue: ReturnType<typeof createLocalVue>;
  let store: Store<{ stations: StationsState }>;
  let wrapper: Wrapper<Vue>;
  let $router: Router;

  beforeEach(() => {
    // Create a fresh Vue instance
    localVue = createLocalVue();
    localVue.use(Vuex);

    // Mock Vuex store
    store = new Vuex.Store({
      modules: {
        stations: {
          namespaced: true,
          state: {
            selectedStation: null,
          },
        },
      },
    });

    // Mock router
    $router = {
      push: vi.fn(),
    } as Router;

    // Reset mocks
    vi.clearAllMocks();
  });

  afterEach(() => {
    if (wrapper) {
      wrapper.destroy();
    }
  });

  it("renders placeholder when no station is selected", () => {
    wrapper = shallowMount(BookingCalendar, {
      localVue,
      store,
      mocks: {
        $router,
      },
    });

    // Should show placeholder
    const placeholder = wrapper.find(".BookingCalendar-placeholder");
    expect(placeholder.exists()).toBe(true);
    expect(placeholder.text()).toContain("Please select a station");

    // Should not show the header with station name
    const header = wrapper.find(".BookingCalendar-header");
    expect(header.exists()).toBe(false);
  });

  it("renders station name when a station is selected", () => {
    // Set a selected station
    store.state.stations.selectedStation = mockStation;

    wrapper = shallowMount(BookingCalendar, {
      localVue,
      store,
      mocks: {
        $router,
      },
    });

    // Should show header with station name
    const header = wrapper.find(".BookingCalendar-header");
    expect(header.exists()).toBe(true);
    expect(header.text()).toContain(mockStation.name);

    // Should not show placeholder
    const placeholder = wrapper.find(".BookingCalendar-placeholder");
    expect(placeholder.exists()).toBe(false);
  });

  it("initializes with the current week from BookingCalendarModule", () => {
    wrapper = shallowMount(BookingCalendar, {
      localVue,
      store,
      mocks: {
        $router,
      },
    });

    // Check that getCurrentWeek was called during component creation
    const vm = wrapper.vm as BookingCalendarVue;
    expect(vm.bookingCalendarModule.getCurrentWeek).toHaveBeenCalled();

    // Check that the week days were set correctly
    expect(vm.weekDays.length).toBe(7);
  });

  it("navigates to the next week", async () => {
    wrapper = shallowMount(BookingCalendar, {
      localVue,
      store,
      mocks: {
        $router,
      },
    });

    const vm = wrapper.vm as BookingCalendarVue;
    const nextWeekButton = wrapper.find(".BookingCalendar-control--next");

    // Click the next week button
    await nextWeekButton.trigger("click");

    // Check that goToNextWeek was called
    expect(vm.bookingCalendarModule.goToNextWeek).toHaveBeenCalled();
  });

  it("navigates to the previous week", async () => {
    wrapper = shallowMount(BookingCalendar, {
      localVue,
      store,
      mocks: {
        $router,
      },
    });

    const vm = wrapper.vm as BookingCalendarVue;
    const prevWeekButton = wrapper.find(".BookingCalendar-control--prev");

    // Click the previous week button
    await prevWeekButton.trigger("click");

    // Check that goToPreviousWeek was called
    expect(vm.bookingCalendarModule.goToPreviousWeek).toHaveBeenCalled();
  });

  it("displays the correct date format for each day", () => {
    // Create a spy on the formatDate method of BookingCalendarModule prototype
    const formatDateSpy = vi
      .fn()
      .mockImplementation((date: Date) => format(date, "EEE dd MMM yyyy"));

    // Create a new mock with the spy
    const mockModule = {
      getCurrentWeek: vi
        .fn()
        .mockReturnValue([new Date("2025-07-10T00:00:00Z")]),
      formatDate: formatDateSpy,
      goToNextWeek: vi.fn(),
      goToPreviousWeek: vi.fn(),
      getBookingsForDay: vi.fn().mockReturnValue([]),
      goToLatestBooking: vi.fn(),
    };

    // Mock the BookingCalendarModule constructor to return our mockModule
    (BookingCalendarModule as ReturnType<typeof vi.fn>).mockImplementation(
      () => mockModule
    );

    wrapper = mount(BookingCalendar, {
      localVue,
      store,
      mocks: {
        $router,
      },
    });

    // Our formatDate spy should have been called during rendering
    expect(formatDateSpy).toHaveBeenCalled();

    // Check the dates displayed in the calendar
    const dates = wrapper.findAll(".BookingCalendar-date");
    expect(dates.length).toBe(1); // We're only returning one date in getCurrentWeek for simplicity
  });

  it("highlights today correctly", () => {
    wrapper = shallowMount(BookingCalendar, {
      localVue,
      store,
      mocks: {
        $router,
      },
    });

    // Count days with the today class
    const todayDays = wrapper.findAll(".BookingCalendar-day--today");
    expect(todayDays.length).toBe(1); // Only one day should be marked as today

    // Check that the "Today" tag is shown
    expect(todayDays.at(0).find(".BookingCalendar-tag").text()).toBe("Today");
  });

  it("fetches bookings for each day", () => {
    // Set a selected station
    store.state.stations.selectedStation = mockStation;

    wrapper = shallowMount(BookingCalendar, {
      localVue,
      store,
      mocks: {
        $router,
      },
    });

    const vm = wrapper.vm as BookingCalendarVue;

    // Mock getBookingsForDay to return mock bookings for a specific day
    const thursday = new Date("2025-07-10T00:00:00Z");
    // The mock function has additional mock methods that we need to access
    const mockedFunction = vm.bookingCalendarModule
      .getBookingsForDay as ReturnType<typeof vi.fn>;
    mockedFunction.mockImplementation((day: Date) => {
      if (day.getTime() === thursday.getTime()) {
        return [{ ...mockBookings[1], type: "pickup" }];
      }
      return [];
    });

    // Call getBookingsForDay for Thursday
    const bookings = vm.getBookingsForDay(thursday);

    // Check that the method was called with the right parameters
    expect(vm.bookingCalendarModule.getBookingsForDay).toHaveBeenCalledWith(
      thursday,
      mockStation
    );

    // Check that the correct bookings were returned
    expect(bookings.length).toBe(1);
    expect(bookings[0].id).toBe("booking2");
  });

  it("navigates to booking details when openBookingDetails is called", async () => {
    // Set a selected station
    store.state.stations.selectedStation = mockStation;

    // Use shallowMount since we're going to directly call the method
    wrapper = shallowMount(BookingCalendar, {
      localVue,
      store,
      mocks: {
        $router,
      },
    });

    const vm = wrapper.vm as BookingCalendarVue;

    // Directly call the openBookingDetails method
    vm.openBookingDetails(mockBookings[0].id);

    // Check that router.push was called with the correct parameters
    expect($router.push).toHaveBeenCalledWith({
      name: "booking-info",
      params: {
        bookingId: mockBookings[0].id,
        stationId: mockStation.id,
      },
    });
  });

  it("goes to the latest booking when button is clicked", async () => {
    // Set a selected station
    store.state.stations.selectedStation = mockStation;

    wrapper = shallowMount(BookingCalendar, {
      localVue,
      store,
      mocks: {
        $router,
      },
    });

    const vm = wrapper.vm as BookingCalendarVue;
    const goToLatestButton = wrapper.find(".BookingCalendar-temp button");

    // Click the "Go to latest booking" button
    await goToLatestButton.trigger("click");

    // Check that goToLatestBooking was called with the selected station
    expect(vm.bookingCalendarModule.goToLatestBooking).toHaveBeenCalledWith(
      mockStation
    );
  });
});
