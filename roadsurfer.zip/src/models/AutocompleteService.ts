export interface AutocompleteService<T> {
  getSuggestions(query: string): Promise<T[]>;
}
