import BookingsService from "@/services/BookingsService";
import StationsService from "@/services/StationsService";
import type { Booking } from "@/models";
import type { Commit } from "vuex";

const bookingsService = new BookingsService();
const stationsService = new StationsService();

interface BookingState {
  selectedBooking: Booking | null;
  loading: boolean;
  error: string | null;
}

const state: BookingState = {
  selectedBooking: null,
  loading: false,
  error: null,
};

const mutations = {
  SET_SELECTED_BOOKING(state: BookingState, booking: Booking | null) {
    state.selectedBooking = booking;
  },
  SET_LOADING(state: BookingState, loading: boolean) {
    state.loading = loading;
  },
  SET_ERROR(state: BookingState, error: string | null) {
    state.error = error;
  },
};

const actions = {
  async fetchBookingByStation(
    { commit }: { commit: Commit },
    { stationId, bookingId }: { stationId: string; bookingId: string }
  ) {
    commit("SET_LOADING", true);
    commit("SET_ERROR", null);

    try {
      const booking = await bookingsService.getBookingByStation(
        stationId,
        bookingId
      );
      if (!booking) {
        throw new Error(`Booking with ID ${bookingId} not found`);
      }

      const stations = await stationsService.getStations();
      const currentStation = stations.find((station) => {
        return station.id === booking.pickupReturnStationId;
      });

      commit("SET_SELECTED_BOOKING", {
        ...booking,
        pickupReturnStationName: currentStation?.name,
      });
    } catch (error) {
      commit(
        "SET_ERROR",
        error instanceof Error ? error.message : "An unknown error occurred"
      );
      commit("SET_SELECTED_BOOKING", null);
    } finally {
      commit("SET_LOADING", false);
    }
  },

  clearSelectedBooking({ commit }: { commit: Commit }) {
    commit("SET_SELECTED_BOOKING", null);
  },
};

const getters = {
  selectedBooking: (state: BookingState) => state.selectedBooking,
  isLoading: (state: BookingState) => state.loading,
  hasError: (state: BookingState) => !!state.error,
  errorMessage: (state: BookingState) => state.error,
};

export default {
  namespaced: true,
  state,
  mutations,
  actions,
  getters,
};
