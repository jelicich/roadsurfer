<template>
  <div class="BookingInfo">
    <BookingDetails />
  </div>
</template>

<script lang="ts">
import Vue from "vue";
import BookingDetails from "@/components/booking-details/BookingDetails.vue";

export default Vue.extend({
  name: "BookingDashboard",

  components: {
    BookingDetails,
  },
});
</script>
