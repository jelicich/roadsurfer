import Vue from "vue";
import VueRouter from "vue-router";
import BookingDashboard from "../views/booking-dashboard/BookingDashboard.vue";

Vue.use(VueRouter);

const router = new VueRouter({
  mode: "history",
  base: import.meta.env.BASE_URL,
  routes: [
    {
      path: "/",
      name: "home",
      component: BookingDashboard,
    },
    {
      path: "/booking-info/:stationId/:bookingId",
      name: "booking-info",
      components: {
        default: BookingDashboard, // Keep the dashboard visible in the background
        modal: () => import("../views/booking-info/BookingInfo.vue"), // Show booking details as modal
      },
      props: {
        modal: true, // Pass route.params as props to the modal component
      },
    },
  ],
});

export default router;
