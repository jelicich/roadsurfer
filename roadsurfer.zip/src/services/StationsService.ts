import ApiService from "@/services/ApiService";
import type { Station } from "@/models";

export default class StationsService {
  private static readonly ENDPOINTS = {
    STATIONS: "https://605c94c36d85de00170da8b4.mockapi.io/stations",
    STATIONS_SUGGESTIONS: (query: string) =>
      `https://605c94c36d85de00170da8b4.mockapi.io/stations?search=${query}`,
  };

  public async getStations(): Promise<Station[]> {
    try {
      return await ApiService.get<Station[]>(
        StationsService.ENDPOINTS.STATIONS
      );
    } catch (error) {
      console.error("Error fetching stations:", error);
      return [];
    }
  }

  public async getSuggestions(query: string): Promise<Station[]> {
    try {
      const data = await ApiService.get<Station[]>(
        StationsService.ENDPOINTS.STATIONS_SUGGESTIONS(query)
      );
      return data ?? [];
    } catch (error) {
      console.error("Error fetching stations:", error);
      return [];
    }
  }
}
