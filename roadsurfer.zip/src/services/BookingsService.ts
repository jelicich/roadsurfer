import ApiService from "@/services/ApiService";
import type { Booking } from "@/models";

export default class BookingsService {
  private static readonly ENDPOINTS = {
    BOOKING: (stationId: string, bookingId: string) =>
      `https://605c94c36d85de00170da8b4.mockapi.io/stations/${stationId}/bookings/${bookingId}`,
  };

  public async getBookingByStation(
    stationId: string,
    bookingId: string
  ): Promise<Booking | null> {
    try {
      return await ApiService.get<Booking>(
        BookingsService.ENDPOINTS.BOOKING(stationId, bookingId)
      );
    } catch (error) {
      console.error("Error fetching stations:", error);
      return null;
    }
  }
}
