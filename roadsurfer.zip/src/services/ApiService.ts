import Notification from "@/modules/Notification";
import Notifications from "@/modules/Notifications";

export default class ApiService {
  private static baseUrl = "";
  private static notificationModule = new Notifications();

  static setBaseUrl(url: string): void {
    this.baseUrl = url;
  }

  private static _buildUrl(endpoint: string): string {
    return `${this.baseUrl}${endpoint}`;
  }

  static async get<T>(endpoint: string): Promise<T> {
    const url = this._buildUrl(endpoint);

    const response = await fetch(url, {
      method: "GET",
    });

    // assume every 404 is no results due to the lack of info in the response
    if (response.status === 404) {
      return null as unknown as T;
    }

    if (!response.ok) {
      const notification = new Notification(
        `HTTP ${response.status}: ${response.statusText}`
      );
      this.notificationModule.add(notification);

      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    return response.json();
  }
}
